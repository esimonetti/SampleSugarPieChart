<?php
$app_strings['LBL_DASHLET_PIE_CHART_LABEL'] = 'Commission Split';
$app_strings['LBL_DASHLET_PIE_CHART_DESCRIPTION'] = 'Commission Split Dashlet';

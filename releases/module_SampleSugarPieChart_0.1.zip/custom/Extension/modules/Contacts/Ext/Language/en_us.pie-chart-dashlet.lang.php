<?php
$mod_strings['LBL_DASHLET_PIE_CHART_LABEL'] = 'Commission Split';
$mod_strings['LBL_DASHLET_PIE_CHART_DESCRIPTION'] = 'Commission Split Dashlet';

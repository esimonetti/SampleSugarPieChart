<?php
$manifest = array (
  'id' => 'SampleSugarPieChart_0.1',
  'built_in_version' => '7.9.0.0',
  'name' => 'SampleSugarPieChart',
  'description' => 'SampleSugarPieChart',
  'version' => '0.1',
  'author' => 'Enrico Simonetti, SugarCRM Inc.',
  'is_uninstallable' => true,
  'published_date' => '2017-07-21 05:30:44',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.9.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/custom/Extension/application/Ext/Language/en_us.pie-chart-dashlet.lang.php',
      'to' => 'custom/Extension/application/Ext/Language/en_us.pie-chart-dashlet.lang.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Contacts/Ext/Language/en_us.pie-chart-dashlet.lang.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Language/en_us.pie-chart-dashlet.lang.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/custom/modules/Contacts/clients/base/api/CommissionApi.php',
      'to' => 'custom/modules/Contacts/clients/base/api/CommissionApi.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/custom/modules/Contacts/clients/base/views/pie-chart-dashlet/pie-chart-dashlet.hbs',
      'to' => 'custom/modules/Contacts/clients/base/views/pie-chart-dashlet/pie-chart-dashlet.hbs',
    ),
    4 => 
    array (
      'from' => '<basepath>/custom/modules/Contacts/clients/base/views/pie-chart-dashlet/pie-chart-dashlet.js',
      'to' => 'custom/modules/Contacts/clients/base/views/pie-chart-dashlet/pie-chart-dashlet.js',
    ),
    5 => 
    array (
      'from' => '<basepath>/custom/modules/Contacts/clients/base/views/pie-chart-dashlet/pie-chart-dashlet.php',
      'to' => 'custom/modules/Contacts/clients/base/views/pie-chart-dashlet/pie-chart-dashlet.php',
    ),
  ),
);
